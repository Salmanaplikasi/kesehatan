import 'regenerator-runtime';
import '../styles/style.css';
import '../styles/responsive.css';